<?php

/*
* Bitcoin Gambling Script - Overfeat
* Copyrighted (c) 2016 - Volcrado Holdings Ltd.
*
* To begun the setup, add your domain at Overfeat.com website and paste your API key at the variable below. 
* Once you are done, open your website URL and you'll be instantly redireted to the installer where you can proceed and complete the site installation.
*
*/

$api_key = "PASTE_YOUR_API_KEY_HERE";