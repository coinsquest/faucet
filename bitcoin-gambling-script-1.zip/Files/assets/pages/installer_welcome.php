<div class="container" style="background:white; padding-bottom:45px; margin-bottom:45px;">
<div class="page-header">
<h1>Install <b>Bitcoin Gambling Script</b></h1>
</div>

<p style="font-size:120%;">Thank you for purchasing <b>Bitcoin Gambling Script</b>. You'll be able to manage and launch your website as soon as this setup is completed.</p>
<p style="font-size:120%;">The process of installation is simple and straightforward. You will be asked to enter the website URL, database details and desired admin login details.</p>

<br>

<p style="font-size:120%;">We're now doing some tests on your web-server to check if the script would be able to function properly on your web-server.</p>

<br>

<?php

function is_valid_domain_name($domain_name) {
    return (preg_match("/^([a-z\d](-*[a-z\d])*)(\.([a-z\d](-*[a-z\d])*))*$/i", $domain_name) //valid chars check
            && preg_match("/^.{1,253}$/", $domain_name) //overall length check
            && preg_match("/^[^\.]{1,63}(\.[^\.]{1,63})*$/", $domain_name)   ); //length of each label
}

$php_version = PHP_VERSION;
$status = 1;

if(version_compare(PHP_VERSION, '5.3.7', '<')) {
$php_version_status = '<span style="color:red;">Incompatible</span>';
$status = 0;
} elseif (version_compare(PHP_VERSION, '5.5.0', '<')) {
$php_version_status = '<span style="color:orange;">Compatible</span>';
} else {
$php_version_status = '<span style="color:green;">OK</span>';
}

$filename = 'config/config.php';

if(is_writable($filename)) {

$writable = '<span style="color:green;">Writable</span>';

} else {

$writable = '<span style="color:red;">Insufficient Permission</span>';
$status = 0;

}

$filename = 'installer.php';

if(is_writable($filename)) {

$writable2 = '<span style="color:green;">Writable</span>';

} else {

$writable2 = '<span style="color:red;">Insufficient Permission</span>';
$status = 0;

}

$filename = 'sql.txt';

if(is_writable($filename)) {

$writable3 = '<span style="color:green;">Writable</span>';

} else {

$writable3 = '<span style="color:red;">Insufficient Permission</span>';
$status = 0;

}

$filename = 'assets/pages/installer_welcome.php';

if(is_writable($filename)) {

$writable4 = '<span style="color:green;">Writable</span>';

} else {

$writable4 = '<span style="color:red;">Insufficient Permission</span>';
$status = 0;

}

if(function_exists('mcrypt_encrypt')) {

$mcrypt = '<span style="color:green;">Installed</span>';

} else {

$mcrypt = '<span style="color:red;">Not Installed</span>';
$status = 0;

}

if(function_exists('mb_strtolower')) {

$mbstring = '<span style="color:green;">Installed</span>';

} else {

$mbstring = '<span style="color:red;">Not Installed</span>';
$status = 0;

}

if(function_exists('curl_exec')) {

$curl = '<span style="color:green;">Installed</span>';

} else {

$curl = '<span style="color:red;">Not Installed</span>';
$status = 0;

}

if(function_exists('gd_info')) {

$gd = '<span style="color:green;">Installed</span>';

} else {

$gd = '<span style="color:red;">Not Installed</span>';
$status = 0;

}

if(function_exists('mysqli_stmt_get_result')) {

$mysqlnd = '<span style="color:green;">Installed</span>';

} else {

$mysqlnd = '<span style="color:red;">Not Installed</span>';
$status = 0;

}

?>

<span style="font-size:135%;"><b>PHP Version</b> &mdash; <?php echo $php_version; ?> &mdash; <b><?php echo $php_version_status; ?></b></span>
<br>
<span style="font-size:135%;"><b>Write Permission #1</b> &mdash; config/config.php &mdash; <b><?php echo $writable; ?></b></span>
<br>
<span style="font-size:135%;"><b>Write Permission #2</b> &mdash; installer.php &mdash; <b><?php echo $writable2; ?></b></span>
<br>
<span style="font-size:135%;"><b>Write Permission #3</b> &mdash; sql.txt &mdash; <b><?php echo $writable3; ?></b></span>
<br>
<span style="font-size:135%;"><b>Write Permission #4</b> &mdash; assets/pages/installer_welcome.php &mdash; <b><?php echo $writable4; ?></b></span>
<br>
<span style="font-size:135%;"><b>Mcrypt</b> &mdash; Availability &mdash; <b><?php echo $mcrypt; ?></b></span>
<br>
<span style="font-size:135%;"><b>mb_string</b> &mdash; Availability &mdash; <b><?php echo $mbstring; ?></b></span>
<br>
<span style="font-size:135%;"><b>Curl (PHP)</b> &mdash; Availability &mdash; <b><?php echo $curl; ?></b></span>
<br>
<span style="font-size:135%;"><b>PHP GD</b> &mdash; Availability &mdash; <b><?php echo $gd; ?></b></span>
<br>
<span style="font-size:135%;"><b>MySQL Native Driver</b> &mdash; Availability &mdash; <b><?php echo $mysqlnd; ?></b></span>

<br>
<br>

<?php if($status == 0) { ?>

<p style="font-size:125%;"><b>Looks like one or more things required for the script to function properly are not available. Please use the above information to advance.</b></p>

<?php } else  { ?>

<?php

function cleanInput($input) {

$search = array(
'@<script[^>]*?>.*?</script>@si',  
'@<[\/\!]*?[^<>]*?>@si',           
'@<style[^>]*?>.*?</style>@siU',   
'@<![\s\S]*?--[ \t\n\r]*>@'       
);

$wipe = array(

"+union+",
"%20union%20",
"/union/*",
' union '

);
 
$output = preg_replace($search, '', $input);
$output = str_replace($wipe,'',$output);

return addslashes(trim($output));

}

$scheme = "http";

if(!empty($s['HTTPS']) && $s['HTTPS'] == 'on') {
	
$scheme = "https";
	
}

$website_url_prepared = cleanInput(str_replace("installer","",$scheme . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']));
$domain_prepared = cleanInput($_SERVER['HTTP_HOST']);

if(isset($_POST['submit'])) {
	
$website_url = cleanInput($_POST['website_url']);
$domain = cleanInput($_POST['domain']);
$contact_email = cleanInput($_POST['contact_email']);

$db_host = cleanInput($_POST['db_host']);
$db_user = cleanInput($_POST['db_user']);
$db_pass = cleanInput($_POST['db_pass']);
$db_name = cleanInput($_POST['db_name']);
	
$email_address = cleanInput($_POST['email_address']);
$user_name = cleanInput($_POST['user_name']);
$password = cleanInput($_POST['password']);
	
if(!filter_var($website_url,FILTER_VALIDATE_URL)) {

echo '<div class="alert alert-danger">
The <b>Website URL</b> is not valid.
</div>';
	
} elseif(!is_valid_domain_name($domain)) {

echo '<div class="alert alert-danger">
The <b>Website Domain</b> is not valid.
</div>';
	
} elseif(!filter_var($contact_email,FILTER_VALIDATE_EMAIL)) {

echo '<div class="alert alert-danger">
The <b>Contact Email</b> is not a valid email.
</div>';
	
} elseif($db_host == "") {

echo '<div class="alert alert-danger">
The <b>DB Host</b> is not valid.
</div>';
	
} elseif($db_user == "") {

echo '<div class="alert alert-danger">
The <b>DB User</b> is not valid.
</div>';
	
} elseif($db_pass == "") {

echo '<div class="alert alert-danger">
The <b>DB Pass</b> is not valid.
</div>';
	
} elseif($db_name == "") {

echo '<div class="alert alert-danger">
The <b>DB Name</b> is not valid.
</div>';
	
} elseif(!filter_var($email_address,FILTER_VALIDATE_EMAIL)) {

echo '<div class="alert alert-danger">
The <b>Email Address</b> is not a valid email.
</div>';
	
} elseif($user_name == "") {
	
echo '<div class="alert alert-danger">
The <b>Username</b> is not valid.
</div>';
	
} elseif(strlen($user_name) > 16) {
	
echo '<div class="alert alert-danger">
The <b>Username</b> length is limited to 16 characters.
</div>';
	
} elseif(preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $user_name)) {

echo '<div class="alert alert-danger">
The <b>Username</b> cannot contain special characters.
</div>';

} elseif($password == "") {
	
echo '<div class="alert alert-danger">
The <b>Password</b> has been left blank.
</div>';
	
} else {
	
$last_character = substr($website_url,-1);

if($last_character != "/") {
	
$website_url = $website_url . "/";
	
}
	
$con = mysqli_connect($db_host,$db_user,$db_pass);

if(!$con) {

echo '<div class="alert alert-danger">
The <b>Database</b> connection details are not valid.
</div>';

} else {
	
mysqli_query($con,"CREATE DATABASE IF NOT EXISTS " . $db_name);	

mysqli_select_db($db_name,$con);
mysqli_query($con,"USE " . $db_name);

// Import the database.	

$templine = "";
$lines = file("sql.txt");

foreach($lines as $line) {

if(substr($line, 0, 2) == '--' || $line == '')

continue;

$templine .= $line;

if(substr(trim($line), -1, 1) == ';') {

mysqli_query($con,$templine);
$templine = '';

}

}

// Create new table, and put the new admin user and site details.

$password_hash = password_hash($password, PASSWORD_DEFAULT, array('cost' => 12));
$noReplyEmail = "no.reply@" . $domain;
$date = date("Y-m-d H:i:s");
$ip = get_IP();

mysqli_query($con,"INSERT INTO users (user_name,user_email,password_hash,user_verified,registration_datetime,registration_ip,last_ip,account_group,admin_powers,account_status,balance) VALUES ('{$user_name}','{$email_address}','{$password_hash}',1,'{$date}','{$ip}','{$ip}',1,1,1,1)");
mysqli_query($con,"UPDATE settings SET value = '{$website_url}' WHERE name = 'website_url'");
mysqli_query($con,"UPDATE settings SET value = '{$domain}' WHERE name = 'domain'");
mysqli_query($con,"UPDATE settings SET value = '{$noReplyEmail}' WHERE name = 'noReplyEmail'");
mysqli_query($con,"UPDATE settings SET value = '{$contact_email}' WHERE name = 'contactEmail'");

// Write the configuration file.

$cookie_hash = hash("sha256","overfeat.com" . time() . time() . time() . uniqid() . uniqid() . mt_rand() . "areebmajeed.me");

$content = '<?php

$api_key = "' . $api_key . '";

define("DB_HOST", "' . $db_host . '");
define("DB_NAME", "' . $db_name . '");
define("DB_USER", "' . $db_user . '");
define("DB_PASS", "' . $db_pass . '");

define("COOKIE_DOMAIN", ".' . $domain . '");
define("COOKIE_SECRET_KEY", "' . $cookie_hash . '");

define("EMAIL_USE_SMTP", false);
define("EMAIL_SMTP_HOST", "ssl://");
define("EMAIL_SMTP_AUTH", true);
define("EMAIL_SMTP_USERNAME", "");
define("EMAIL_SMTP_PASSWORD", "");
define("EMAIL_SMTP_PORT", 465);
define("EMAIL_SMTP_ENCRYPTION", "ssl");

$eval_enabled = 0;
$installed = 1;

?>';

file_put_contents("config/config.php",$content);

// Vomit the success message.

echo '<div class="alert alert-success">
Your website has been <b>successfully installed</b>. Redirecting you to admin login in 7 seconds.
</div>';

echo '<script>

window.setTimeout(function() {

window.location = "index";

}, 7000);

</script>';
	
unlink("assets/pages/installer_welcome.php");
unlink("install.php");
unlink("sql.txt");
	
}	
	
}	
	
} else {
	
echo '<p style="font-size:220%;">All <b>good</b>! Let\'s start.</p>';
	
}

?>

<br>

<form action="installer" method="post">

<div class="form-group">
<label class="control-label">Website URL:</label>
<input type="text" name="website_url" class="form-control" value="<?php echo $website_url_prepared; ?>">
</div>

<div class="form-group">
<label class="control-label">Website Domain:</label>
<input type="text" name="domain" class="form-control" value="<?php echo $domain_prepared; ?>">
</div>

<div class="form-group">
<label class="control-label">Contact Email:</label>
<input type="text" name="contact_email" class="form-control" placeholder="jane.austen@poets.com">
</div>

<hr>

<div class="form-group">
<label class="control-label">Database Host:</label>
<input type="text" name="db_host" class="form-control" value="localhost">
</div>

<div class="form-group">
<label class="control-label">Database User:</label>
<input type="text" name="db_user" class="form-control">
</div>

<div class="form-group">
<label class="control-label">Database Password:</label>
<input type="password" name="db_pass" class="form-control">
</div>

<div class="form-group">
<label class="control-label">Database Name:</label>
<input type="text" name="db_name" class="form-control">
</div>

<hr>

<div class="form-group">
<label class="control-label">Email Address:</label>
<input type="email" name="email_address" class="form-control">
</div>

<div class="form-group">
<label class="control-label">Desired Username:</label>
<input type="text" name="user_name" class="form-control">
</div>

<div class="form-group">
<label class="control-label">Desired Password:</label>
<input type="password" name="password" class="form-control">
</div>

<input type="submit" name="submit" value="Install Script" class="btn btn-primary">

</form>

<?php } ?>

</div>